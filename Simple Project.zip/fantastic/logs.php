<?php
include 'config.php';

$result = mysqli_query($link, "SELECT * FROM tbllogs WHERE module = 'Barcode Scanner' ORDER BY datelog DESC, timelog DESC LIMIT 20");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scanned Logs</title>
</head>
<body>
    <h2>Scanned Students Logs</h2>
    <ul>
        <?php while ($log = mysqli_fetch_assoc($result)) {
            echo "<li>{$log['datelog']} {$log['timelog']} - {$log['action']}</li>";
        } ?>
    </ul>
    <a href="security-index.php">Back</a>
</body>
</html>
