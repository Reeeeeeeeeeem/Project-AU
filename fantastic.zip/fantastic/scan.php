<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['barcode'])) {
    $barcode = $_POST['barcode'];

    // Fetch student details
    $query = "SELECT * FROM tblstudents WHERE studentnumber = ?";
    $stmt = mysqli_prepare($link, $query);
    mysqli_stmt_bind_param($stmt, "s", $barcode);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $student = mysqli_fetch_assoc($result);

    if ($student) {
        // Log scan
        $datelog = date("Y-m-d");
        $timelog = date("H:i:s");
        $action = "Scanned Student - {$student['studentnumber']}";
        $module = "Barcode Scanner";
        $performedby = "Security";

        $logQuery = "INSERT INTO tbllogs (datelog, timelog, action, module, performedby) VALUES (?, ?, ?, ?, ?)";
        $logStmt = mysqli_prepare($link, $logQuery);
        mysqli_stmt_bind_param($logStmt, "sssss", $datelog, $timelog, $action, $module, $performedby);
        mysqli_stmt_execute($logStmt);

        // Return student details as JSON
        echo json_encode([
            "status" => "success",
            "message" => "Student Scanned Successfully!",
            "student" => $student
        ]);
    } else {
        echo json_encode([
            "status" => "error",
            "message" => "Student not found."
        ]);
    }
    exit;
}
?>
