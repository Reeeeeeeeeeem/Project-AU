﻿Imports ITC124_2C_Database.Class1
Public Class frmmain
    Private Sub frmmain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If logintype = "ADMINISTRATOR" Then
            AccountsToolStripMenuItem.Visible = True
            EquipmentsToolStripMenuItem.Visible = True
            ReportsToolStripMenuItem.Visible = True
        Else
            AccountsToolStripMenuItem.Visible = False
            EquipmentsToolStripMenuItem.Visible = True
            ReportsToolStripMenuItem.Visible = False
        End If
    End Sub

    Private Sub AccountsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AccountsToolStripMenuItem.Click
        Dim accountsfrm As New frmaccounts
        accountsfrm.MdiParent = Me
        accountsfrm.Show()
    End Sub

    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        loginuser = ""
        logintype = ""
        Dim loginfrm As New frmlogin
        loginfrm.Show()
        Me.Close()
    End Sub

    Private Sub EquipmentsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EquipmentsToolStripMenuItem.Click
        Dim equipmentsfrm As New frmequipments
        equipmentsfrm.MdiParent = Me
        equipmentsfrm.Show()
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        AboutBox1.Show()
        Me.Hide()
    End Sub

    Private Sub LogsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogsToolStripMenuItem.Click
        Dim logsfrm As New frmlogs
        logsfrm.MdiParent = Me
        logsfrm.Show()
    End Sub
End Class