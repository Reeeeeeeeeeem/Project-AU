﻿Imports ITC124_2C_Database.Class1
Public Class frmlogin
    Private Sub btnlogin_Click(sender As Object, e As EventArgs) Handles btnlogin.Click
        Try
            DSRec.Clear()
            DSRec = GetDataTable("SELECT * FROM tblaccounts WHERE username = '" + txtusername.Text + "' AND password = '" + txtpassword.Text +
                                 "' AND status = 'ACTIVE'")
            If DSRec.Rows.Count > 0 Then
                Dim mainfrm As New frmmain
                loginuser = txtusername.Text
                logintype = DSRec.Rows(0).Item("usertype").ToString()
                mainfrm.ToolStripStatusLabel1.Text = "USERNAME:" + loginuser
                mainfrm.ToolStripStatusLabel2.Text = "USER TYPE:" + logintype
                mainfrm.Show()
                Me.Hide()
            Else
                MessageBox.Show("Incorrect username or password or account is inactive", "Message", MessageBoxButtons.OK, MessageBoxIcon.Stop)
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error on login button", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub chkshow_CheckedChanged(sender As Object, e As EventArgs) Handles chkshow.CheckedChanged
        If chkshow.Checked Then
            txtpassword.PasswordChar = ""
        Else
            txtpassword.PasswordChar = "*"
        End If
    End Sub

    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        txtusername.Clear()
        txtpassword.Clear()
        txtusername.Select()
    End Sub

    Private Sub txtusername_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtusername.KeyPress
        If Asc(e.KeyChar) = 13 Then
            btnlogin_Click(sender, e)
        End If
    End Sub

    Private Sub txtpassword_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtpassword.KeyPress
        If Asc(e.KeyChar) = 13 Then
            btnlogin_Click(sender, e)
        End If
    End Sub
End Class