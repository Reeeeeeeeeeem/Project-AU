﻿Public NotInheritable Class AboutBox1

    Private Sub AboutBox1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Set the title of the form.
        Dim ApplicationTitle As String
        If My.Application.Info.Title <> "" Then
            ApplicationTitle = My.Application.Info.Title
        Else
            ApplicationTitle = System.IO.Path.GetFileNameWithoutExtension(My.Application.Info.AssemblyName)
        End If
        Me.Text = String.Format("About {0}", ApplicationTitle)
        ' Initialize all of the text displayed on the About Box.
        ' TODO: Customize the application's assembly information in the "Application" pane of the project 
        '    properties dialog (under the "Project" menu).
        Me.LabelProductName.Text = "DATABASE PROJECT"
        Me.LabelVersion.Text = "UMALI, JONATHAN I."
        Me.LabelCopyright.Text = "December 06, 2023"
        Me.LabelCompanyName.Text = "SY 2023 - 2024"
        Me.TextBoxDescription.Text = "The application comprises two forms, frmaccounts and frmequipments, " +
                                     "facilitating the creation, modification, and deletion of user accounts and equipment records." +
                                     " Utilizing a shared database interaction module, the system incorporates robust input validation, " +
                                      "ensuring data integrity. Logging actions in the tbllogs table enhances traceability for key events." +
                                      "The frmaddequipment form features a Clear button (btnclear) for resetting input fields and error indicators," +
                                      "streamlining the process Of adding New equipment details." +
                                      "In summary, this application provides an intuitive " +
                                        "interface for seamlessly handling user accounts And equipment records" +
                                        "with a focus on data accuracy and traceable actions."
    End Sub

    Private Sub OKButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OKButton.Click
        Me.Close()
    End Sub


End Class
