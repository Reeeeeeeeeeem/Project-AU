﻿Imports ITC124_2C_Database.Class1
Public Class frmupdate
    Private Sub chkshow_CheckedChanged(sender As Object, e As EventArgs) Handles chkshow.CheckedChanged
        If chkshow.Checked Then
            txtpassword.PasswordChar = ""
        Else
            txtpassword.PasswordChar = "*"
        End If
    End Sub
    Dim errorCount As Integer
    Private Sub btnsave_Click(sender As Object, e As EventArgs) Handles btnsave.Click
        Try
            errorCount = 0
            ErrorProvider1.Clear()
            'validations
            If String.IsNullOrEmpty(txtusername.Text) Then
                ErrorProvider1.SetError(txtusername, "Input is required")
                errorCount = errorCount + 1
            End If
            If String.IsNullOrEmpty(txtpassword.Text) Then
                ErrorProvider1.SetError(txtpassword, "Input is required")
                errorCount = errorCount + 1
            End If
            If cmbtype.SelectedIndex < 0 Then
                ErrorProvider1.SetError(cmbtype, "Input is required")
                errorCount = errorCount + 1
            End If
            If cmbstatus.SelectedIndex < 0 Then
                ErrorProvider1.SetError(cmbtype, "Input is required")
                errorCount = errorCount + 1
            End If

            If errorCount = 0 Then
                Dim dialog As DialogResult = MessageBox.Show("Are you sure want to update this account? ", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                If dialog = DialogResult.Yes Then
                    'execute an update statement using the identifier
                    executeSQL("UPDATE tblaccounts SET password = '" + txtpassword.Text + "',usertype = '" + cmbtype.Text.ToUpper + "',status = '" +
                               cmbstatus.Text.ToUpper + "' WHERE username = '" + txtusername.Text + "' ")
                    If rowAffected > 0 Then
                        executeSQL("INSERT INTO tbllogs VALUES ('" + DateTime.Now.ToShortDateString + "','" + DateTime.Now.ToLongTimeString() + "','UPDATE','" +
                               txtusername.Text + "','" + loginuser + "','ACCOUNTS')")
                        MessageBox.Show("Account Updated", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Me.Close()
                    End If
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error on btnsave_Click", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

End Class