﻿Imports ITC124_2C_Database.Class1
Public Class frmequipments
    Private Sub frmequipments_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            DSRec.Clear()
            DSRec = GetDataTable("SELECT * FROM tblequipment ORDER BY AssetNumber")
            DataGridView1.DataSource = DSRec
            DataGridView1.CurrentCell = DataGridView1.Rows(0).Cells(0)
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error on frmaccounts_Load", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnrefresh_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        frmequipments_Load(sender, e)
    End Sub

    Private Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        Try
            DSRec.Clear()
            DSRec = GetDataTable("SELECT * FROM tblequipment WHERE AssetNumber LIKE '%" + txtsearch.Text + "%' OR SerialNumber LIKE '%" + txtsearch.Text +
                                 "%' ORDER BY AssetNumber")
            DataGridView1.DataSource = DSRec
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error on btnsearch_Click", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub txtsearch_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtsearch.KeyPress
        If Asc(e.KeyChar) Then
            btnsearch_Click(sender, e)
        End If
    End Sub

    Private Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        Try
            Dim dialog As DialogResult = MessageBox.Show("Are you sure you want to delete this equipment?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If dialog = DialogResult.Yes Then
                ' execute the delete statement using the primary key
                executeSQL("DELETE FROM tblequipment WHERE AssetNumber = '" + an + "'")
                If rowAffected > 0 Then
                    executeSQL("INSERT INTO tbllogs VALUES ('" + DateTime.Now.ToShortDateString + "','" + DateTime.Now.ToLongTimeString() + "','DELETE','" +
                           an + "','" + loginuser + "','EQUIPMENTS')")
                    MessageBox.Show("Equipment Deleted", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error on btndelete_Click", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Dim an, sn, type, manu, year, descrip, branch, depart, status As String

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Try
            'this codes allows getting of each column on the data grid
            an = DataGridView1.Rows(e.RowIndex).Cells(0).Value.ToString()
            sn = DataGridView1.Rows(e.RowIndex).Cells(1).Value.ToString()
            type = DataGridView1.Rows(e.RowIndex).Cells(2).Value.ToString()
            manu = DataGridView1.Rows(e.RowIndex).Cells(3).Value.ToString()
            year = DataGridView1.Rows(e.RowIndex).Cells(4).Value.ToString()
            descrip = DataGridView1.Rows(e.RowIndex).Cells(5).Value.ToString()
            branch = DataGridView1.Rows(e.RowIndex).Cells(6).Value.ToString()
            depart = DataGridView1.Rows(e.RowIndex).Cells(7).Value.ToString()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error on DataGridView1_CellClick", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        Dim addequipment As New frmaddequipment
        frmaddequipment.Show()
    End Sub

    Private Sub btnupdate_Click(sender As Object, e As EventArgs) Handles btnupdate.Click
        Try
            Dim updateequipment As New frmupdateequipment
            updateequipment.txtan.Text = an
            updateequipment.txtsn.Text = sn
            If type = "MONITOR" Then
                updateequipment.cmbtype.SelectedIndex = 0
            ElseIf type = "CPU" Then
                updateequipment.cmbtype.SelectedIndex = 1
            ElseIf type = "KEYBOARD" Then
                updateequipment.cmbtype.SelectedIndex = 2
            ElseIf type = "MOUSE" Then
                updateequipment.cmbtype.SelectedIndex = 3
            ElseIf type = "AVR" Then
                updateequipment.cmbtype.SelectedIndex = 4
            ElseIf type = "MAC" Then
                updateequipment.cmbtype.SelectedIndex = 5
            ElseIf type = "PRINTER" Then
                updateequipment.cmbtype.SelectedIndex = 6
            Else
                updateequipment.cmbtype.SelectedIndex = 7
            End If

            updateequipment.txtmanufacturer.Text = manu
            updateequipment.txtyear.Text = year
            updateequipment.txtdescrip.Text = descrip

            If branch = "Juan Sumulong Campus" Then
                updateequipment.cmbbranch.SelectedIndex = 0
            ElseIf branch = "Apolinario Mabini Campus" Then
                updateequipment.cmbbranch.SelectedIndex = 1
            ElseIf branch = "Andres Bonifacio Campus" Then
                updateequipment.cmbbranch.SelectedIndex = 2
            ElseIf branch = "Jose Abad Santos Campus" Then
                updateequipment.cmbbranch.SelectedIndex = 3
            ElseIf branch = "Jose Rizal Campus" Then
                updateequipment.cmbbranch.SelectedIndex = 4
            ElseIf branch = "Elisa Esguerra Campus" Then
                updateequipment.cmbbranch.SelectedIndex = 5
            ElseIf branch = "Plaridel Campus" Then
                updateequipment.cmbbranch.SelectedIndex = 6
            Else
                updateequipment.cmbbranch.SelectedIndex = 7
            End If

            If depart = "College of Arts and Sciences" Then
                updateequipment.cmbdepart.SelectedIndex = 0
            ElseIf depart = "College of Criminal Justice Education" Then
                updateequipment.cmbdepart.SelectedIndex = 1
            ElseIf depart = "College of Medical Laboratory Science" Then
                updateequipment.cmbdepart.SelectedIndex = 2
            ElseIf depart = "College of Nursing" Then
                updateequipment.cmbdepart.SelectedIndex = 3
            ElseIf depart = "College of Pharmacy" Then
                updateequipment.cmbdepart.SelectedIndex = 4
            ElseIf depart = "College of Physical Therapy" Then
                updateequipment.cmbdepart.SelectedIndex = 5
            ElseIf depart = "College of Radiologic Technology" Then
                updateequipment.cmbdepart.SelectedIndex = 6
            ElseIf depart = "Information Technology Education" Then
                updateequipment.cmbdepart.SelectedIndex = 7
            ElseIf depart = "INSTITUTE OF ACCOUNTANCY" Then
                updateequipment.cmbdepart.SelectedIndex = 8
            ElseIf depart = "SCHOOL OF BUSINESS ADMINISTRATION" Then
                updateequipment.cmbdepart.SelectedIndex = 9
            ElseIf depart = "SCHOOL OF BUSINESS AND COMMERCE" Then
                updateequipment.cmbdepart.SelectedIndex = 10
            ElseIf depart = "SCHOOL OF BUSINESS TECHNOLOGY" Then
                updateequipment.cmbdepart.SelectedIndex = 11
            ElseIf depart = "SCHOOL OF COMPUTER SCIENCE" Then
                updateequipment.cmbdepart.SelectedIndex = 12
            ElseIf depart = "SCHOOL OF EDUCATION" Then
                updateequipment.cmbdepart.SelectedIndex = 13
            ElseIf depart = "SCHOOL OF HOSPITALITY AND TOURISM MANAGEMENT" Then
                updateequipment.cmbdepart.SelectedIndex = 14
            ElseIf depart = "SCHOOL OF MIDWIFERY" Then
                updateequipment.cmbdepart.SelectedIndex = 15
            Else
                updateequipment.cmbdepart.SelectedIndex = 16
            End If

            updateequipment.Show()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error on btnupdate_Click", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class