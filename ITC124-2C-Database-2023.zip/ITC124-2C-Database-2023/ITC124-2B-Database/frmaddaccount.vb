﻿Imports ITC124_2C_Database.Class1
Public Class frmaddaccount
    Dim errorCount As Integer
    Private Sub btnsave_Click(sender As Object, e As EventArgs) Handles btnsave.Click
        Try
            errorCount = 0
            ErrorProvider1.Clear()
            'validations
            If String.IsNullOrEmpty(txtusername.Text) Then
                ErrorProvider1.SetError(txtusername, "Input is required")
                errorCount = errorCount + 1
            End If
            If String.IsNullOrEmpty(txtpassword.Text) Then
                ErrorProvider1.SetError(txtpassword, "Input is required")
                errorCount = errorCount + 1
            End If
            If cmbtype.SelectedIndex < 0 Then
                ErrorProvider1.SetError(cmbtype, "Input is required")
                errorCount = errorCount + 1
            End If
            'checking if username is existing
            DSRec.Clear()
            DSRec = GetDataTable("SELECT * FROM tblaccounts WHERE username = '" + txtusername.Text + "'")
            If DSRec.Rows.Count > 0 Then
                ErrorProvider1.SetError(txtusername, "Username is already in use")
                errorCount = errorCount + 1
            End If
            'saving
            If errorCount = 0 Then
                Dim dialog As DialogResult = MessageBox.Show("Are you sure you want to add this account?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If dialog = DialogResult.Yes Then
                    'execute INSERT statement to record the data to the table
                    executeSQL("INSERT INTO tblaccounts (username, password, usertype, status, email, createdby, datecreated) VALUES ('" + txtusername.Text + "','" +
                               txtpassword.Text + "','" + cmbtype.Text.ToUpper + "','ACTIVE','" + txtemail.Text + "','" + loginuser + "','" +
                               DateTime.Now.ToString("MM/dd/yyyy") + "')")
                    If rowAffected > 0 Then
                        MessageBox.Show("New account added!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Me.Close()
                        frmaccounts.Activate()
                    End If
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error on btnsave_Click", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub chkshow_CheckedChanged(sender As Object, e As EventArgs) Handles chkshow.CheckedChanged
        If chkshow.Checked Then
            txtpassword.PasswordChar = ""
        Else
            txtpassword.PasswordChar = "*"
        End If
    End Sub

    Private Sub frmaddaccount_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class