﻿Imports ITC124_2C_Database.Class1
Public Class frmaccounts
    Private Sub frmaccounts_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            DSRec.Clear()
            DSRec = GetDataTable("SELECT * FROM tblaccounts ORDER BY username")
            DataGridView1.DataSource = DSRec
            DataGridView1.Columns(1).Visible = False
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error on frmaccounts_Load", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        Dim addaccountfrm As New frmaddaccount
        addaccountfrm.Show()
    End Sub

    Private Sub btnrefresh_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        frmaccounts_Load(sender, e)
    End Sub

    Private Sub btnsearch_Click(sender As Object, e As EventArgs) Handles btnsearch.Click
        Try
            DSRec.Clear()
            DSRec = GetDataTable("SELECT * FROM tblaccounts WHERE username LIKE '%" + txtsearch.Text + "%' OR usertype LIKE '%" + txtsearch.Text +
                                 "%' ORDER BY username")
            DataGridView1.DataSource = DSRec
            DataGridView1.Columns(1).Visible = False
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error on btnsearch_Click", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub txtsearch_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtsearch.KeyPress
        If Asc(e.KeyChar) Then
            btnsearch_Click(sender, e)
        End If
    End Sub

    Private Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        Try
            Dim dialog As DialogResult = MessageBox.Show("Are you sure you want to delete this account?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If dialog = DialogResult.Yes Then
                'execute the delete statement using the primary key
                executeSQL("DELETE FROM tblaccounts WHERE username = '" + selecteduser + "'")
                If rowAffected > 0 Then
                    executeSQL("INSERT INTO tbllogs VALUES ('" + DateTime.Now.ToShortDateString + "','" + DateTime.Now.ToLongTimeString() + "','DELETE','" +
                               selecteduser + "','" + loginuser + "','ACCOUNTS')")
                    MessageBox.Show("Account Deleted", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error on btndelete_Click", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Dim selecteduser, selectedpass, selectedemail, selectedtype, selectedstatus As String

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Try
            'this codes allows getting of each column on the data grid
            selecteduser = DataGridView1.Rows(e.RowIndex).Cells(0).Value.ToString()
            selectedpass = DataGridView1.Rows(e.RowIndex).Cells(1).Value.ToString()
            selectedtype = DataGridView1.Rows(e.RowIndex).Cells(2).Value.ToString()
            selectedstatus = DataGridView1.Rows(e.RowIndex).Cells(3).Value.ToString()
            selectedemail = DataGridView1.Rows(e.RowIndex).Cells(4).Value.ToString()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error on DataGridView1_CellClick", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnupdate_Click(sender As Object, e As EventArgs) Handles btnupdate.Click
        Try
            Dim updateuserfrm As New frmupdate
            updateuserfrm.txtusername.Text = selecteduser
            updateuserfrm.txtpassword.Text = selectedpass
            If selectedtype = "ADMINISTRATOR" Then
                updateuserfrm.cmbtype.SelectedIndex = 0
            ElseIf selectedtype = "TECHNICAL" Then
                updateuserfrm.cmbtype.SelectedIndex = 1
            Else
                updateuserfrm.cmbtype.SelectedIndex = 2
            End If

            If selectedstatus = "ACTIVE" Then
                updateuserfrm.cmbstatus.SelectedIndex = 0
            Else
                updateuserfrm.cmbstatus.SelectedIndex = 1
            End If
            updateuserfrm.txtemail.Text = selectedemail
            updateuserfrm.Show()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error on btnupdate_Click", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class