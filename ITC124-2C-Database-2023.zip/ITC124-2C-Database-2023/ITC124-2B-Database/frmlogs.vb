﻿Imports ITC124_2C_Database.Class1
Public Class frmlogs
    Private Sub frmlogs_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            DSRec.Clear()
            DSRec = GetDataTable("SELECT * FROM tbllogs ORDER BY datelog")
            DataGridView1.DataSource = DSRec
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error on frmaccounts_Load", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        Try
            Dim dialog As DialogResult = MessageBox.Show("Are you sure you want to delete this equipment?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If dialog = DialogResult.Yes Then
                ' execute the delete statement using the primary key
                executeSQL("DELETE FROM tbllogs")
                If rowAffected > 0 Then
                    executeSQL("INSERT INTO tbllogs VALUES ('" + DateTime.Now.ToShortDateString + "','" + DateTime.Now.ToLongTimeString() +
                               "','DELETE','ALL LOGS','" + loginuser + "','LOGS')")
                    MessageBox.Show("Equipment Deleted", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error on btndelete_Click", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnrefresh_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        frmlogs_Load(sender, e)
    End Sub
End Class