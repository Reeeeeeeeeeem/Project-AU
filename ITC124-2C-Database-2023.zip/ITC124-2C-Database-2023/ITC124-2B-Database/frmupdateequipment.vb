﻿Imports ITC124_2C_Database.Class1
Public Class frmupdateequipment
    Dim errorCount As Integer
    Private Sub btnsave_Click(sender As Object, e As EventArgs) Handles btnsave.Click
        Try
            errorCount = 0
            ErrorProvider1.Clear()

            ' Validations
            If String.IsNullOrEmpty(txtan.Text) Then
                ErrorProvider1.SetError(txtan, "Asset Number is required")
                errorCount += 1
            End If

            If String.IsNullOrEmpty(txtsn.Text) Then
                ErrorProvider1.SetError(txtsn, "Serial Number is required")
                errorCount += 1
            End If

            If cmbtype.SelectedIndex < 0 Then
                ErrorProvider1.SetError(cmbtype, "Type is required")
                errorCount += 1
            End If

            If String.IsNullOrEmpty(txtmanufacturer.Text) Then
                ErrorProvider1.SetError(txtmanufacturer, "Manufacturer is required")
                errorCount += 1
            End If

            If String.IsNullOrEmpty(txtyear.Text) Then
                ErrorProvider1.SetError(txtyear, "Year Model is required")
                errorCount += 1
            ElseIf Not IsNumeric(txtyear.Text) Then
                ErrorProvider1.SetError(txtyear, "Year should be numeric")
                errorCount += 1
            ElseIf txtyear.Text.Length <> 4 Then
                ErrorProvider1.SetError(txtyear, "Year should contain 4 characters")
                errorCount += 1
            End If

            If cmbbranch.SelectedIndex < 0 Then
                ErrorProvider1.SetError(cmbbranch, "Branch is required")
                errorCount += 1
            End If

            If cmbdepart.SelectedIndex < 0 Then
                ErrorProvider1.SetError(cmbdepart, "Department is required")
                errorCount += 1
            End If

            ' Saving
            If errorCount = 0 Then
                Dim dialog As DialogResult = MessageBox.Show("Are you sure you want to update this equipment?", "Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

                If dialog = DialogResult.Yes Then
                    ' Execute UPDATE statement to update the equipment details
                    executeSQL("UPDATE tblequipment SET SerialNumber = '" + txtsn.Text + "', Type = '" + cmbtype.Text + "', " +
                               "Manufacturer = '" + txtmanufacturer.Text + "', YearModel = '" + txtyear.Text + "', Description = '" + txtdescrip.Text + "', " +
                               "Branch = '" + cmbbranch.Text + "', Department = '" + cmbdepart.Text + "' WHERE AssetNumber = '" + txtan.Text + "'")

                    If rowAffected > 0 Then
                        executeSQL("INSERT INTO tbllogs VALUES ('" + DateTime.Now.ToShortDateString + "','" + DateTime.Now.ToLongTimeString() + "','UPDATE','" +
                               txtan.Text + "','" + loginuser + "','EQUIPMENTS')")
                        MessageBox.Show("Equipment Updated", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Me.Close()
                    End If
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error on btnSave_Click", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        Try
            ' Clear textboxes
            txtsn.Clear()
            cmbtype.SelectedIndex = -1
            txtmanufacturer.Clear()
            txtyear.Clear()
            txtdescrip.Clear()
            cmbbranch.SelectedIndex = -1
            cmbdepart.SelectedIndex = -1

            ' Clear error providers
            ErrorProvider1.Clear()

            ' Reset error count
            errorCount = 0
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error on btnclear_Click", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

End Class