﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmupdateequipment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnclear = New System.Windows.Forms.Button()
        Me.btnsave = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.cmbdepart = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cmbbranch = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtdescrip = New System.Windows.Forms.RichTextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtyear = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtmanufacturer = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cmbtype = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtsn = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtan = New System.Windows.Forms.TextBox()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnclear
        '
        Me.btnclear.BackColor = System.Drawing.Color.Yellow
        Me.btnclear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnclear.Location = New System.Drawing.Point(396, 219)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(166, 57)
        Me.btnclear.TabIndex = 35
        Me.btnclear.Text = "&Clear"
        Me.btnclear.UseVisualStyleBackColor = False
        '
        'btnsave
        '
        Me.btnsave.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.btnsave.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnsave.Location = New System.Drawing.Point(211, 219)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(166, 57)
        Me.btnsave.TabIndex = 34
        Me.btnsave.Text = "&Save"
        Me.btnsave.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(325, 180)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(65, 13)
        Me.Label8.TabIndex = 33
        Me.Label8.Text = "Department:"
        '
        'cmbdepart
        '
        Me.cmbdepart.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbdepart.FormattingEnabled = True
        Me.cmbdepart.Items.AddRange(New Object() {"College of Arts and Sciences", "College of Criminal Justice Education", "College of Medical Laboratory Science", "College of Nursing", "College of Pharmacy", "College of Physical Therapy", "College of Radiologic Technology", "Information Technology Education", "Institute of Accountancy", "School of Business Administration", "School of Business and Commerce", "School of Business Technology", "School of Computer Science", "School of Education", "School of Hospitality and Tourism Management", "School of Midwifery", "School Psychology"})
        Me.cmbdepart.Location = New System.Drawing.Point(396, 172)
        Me.cmbdepart.Name = "cmbdepart"
        Me.cmbdepart.Size = New System.Drawing.Size(166, 21)
        Me.cmbdepart.TabIndex = 32
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(346, 146)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(44, 13)
        Me.Label7.TabIndex = 31
        Me.Label7.Text = "Branch:"
        '
        'cmbbranch
        '
        Me.cmbbranch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbbranch.FormattingEnabled = True
        Me.cmbbranch.Items.AddRange(New Object() {"Juan Sumulong Campus", "Apolinario Mabini Campus", "Andres Bonifacio Campus", "Jose Abad Santos Campus", "Jose Rizal Campus", "Elisa Esguerra Campus", "Plaridel Campus", "F.G Calderon Campus"})
        Me.cmbbranch.Location = New System.Drawing.Point(396, 139)
        Me.cmbbranch.Name = "cmbbranch"
        Me.cmbbranch.Size = New System.Drawing.Size(166, 21)
        Me.cmbbranch.TabIndex = 30
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(314, 34)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(63, 13)
        Me.Label6.TabIndex = 29
        Me.Label6.Text = "Description:"
        '
        'txtdescrip
        '
        Me.txtdescrip.Location = New System.Drawing.Point(396, 34)
        Me.txtdescrip.Name = "txtdescrip"
        Me.txtdescrip.Size = New System.Drawing.Size(166, 52)
        Me.txtdescrip.TabIndex = 28
        Me.txtdescrip.Text = ""
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(47, 180)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 13)
        Me.Label5.TabIndex = 27
        Me.Label5.Text = "Year Model:"
        '
        'txtyear
        '
        Me.txtyear.Location = New System.Drawing.Point(126, 173)
        Me.txtyear.Name = "txtyear"
        Me.txtyear.Size = New System.Drawing.Size(166, 20)
        Me.txtyear.TabIndex = 26
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(44, 154)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(73, 13)
        Me.Label4.TabIndex = 25
        Me.Label4.Text = "Manufacturer:"
        '
        'txtmanufacturer
        '
        Me.txtmanufacturer.Location = New System.Drawing.Point(126, 147)
        Me.txtmanufacturer.Name = "txtmanufacturer"
        Me.txtmanufacturer.Size = New System.Drawing.Size(166, 20)
        Me.txtmanufacturer.TabIndex = 24
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(77, 110)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(34, 13)
        Me.Label3.TabIndex = 23
        Me.Label3.Text = "Type:"
        '
        'cmbtype
        '
        Me.cmbtype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbtype.FormattingEnabled = True
        Me.cmbtype.Items.AddRange(New Object() {"Monitor", "CPU", "Keyboard", "Mouse", "AVR", "MAC", "Printer", "Projector"})
        Me.cmbtype.Location = New System.Drawing.Point(126, 102)
        Me.cmbtype.Name = "cmbtype"
        Me.cmbtype.Size = New System.Drawing.Size(166, 21)
        Me.cmbtype.TabIndex = 22
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(44, 63)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 13)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "Serial Number:"
        '
        'txtsn
        '
        Me.txtsn.Location = New System.Drawing.Point(126, 56)
        Me.txtsn.Name = "txtsn"
        Me.txtsn.Size = New System.Drawing.Size(166, 20)
        Me.txtsn.TabIndex = 20
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(44, 37)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 13)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Asset Number:"
        '
        'txtan
        '
        Me.txtan.Location = New System.Drawing.Point(126, 30)
        Me.txtan.Name = "txtan"
        Me.txtan.ReadOnly = True
        Me.txtan.Size = New System.Drawing.Size(166, 20)
        Me.txtan.TabIndex = 18
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'frmupdateequipment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.ClientSize = New System.Drawing.Size(610, 347)
        Me.Controls.Add(Me.btnclear)
        Me.Controls.Add(Me.btnsave)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.cmbdepart)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.cmbbranch)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtdescrip)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtyear)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtmanufacturer)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cmbtype)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtsn)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtan)
        Me.MaximizeBox = False
        Me.Name = "frmupdateequipment"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Update Equipment"
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnclear As Button
    Friend WithEvents btnsave As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents cmbdepart As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents cmbbranch As ComboBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtdescrip As RichTextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtyear As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtmanufacturer As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents cmbtype As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtsn As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtan As TextBox
    Friend WithEvents ErrorProvider1 As ErrorProvider
End Class
