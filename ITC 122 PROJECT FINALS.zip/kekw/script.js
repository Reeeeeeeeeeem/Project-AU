// Switch background functions
		function switchToImageBackground(imagePath, imageCaption, textImagePath, textCaption) {
			const page = document.getElementById('page');
				page.classList.add('image-background');
				page.style.backgroundImage = `url('${imagePath}')`;
				document.getElementById('video-background').style.opacity = 0;
				document.getElementById('content').style.display = 'block';
				document.getElementById('register-button').style.display = 'none';
		}

		function switchToVideoBackground() {
			const page = document.getElementById('page');
				page.classList.remove('image-background');
				page.style.backgroundImage = '';
				document.getElementById('video-background').style.opacity = 1;
				document.getElementById('content').style.display = 'none';
				document.getElementById('register-button').style.display = 'block';
		}

		// Show icons functions
		function showAssault() {
			document.getElementById('assault-content').style.display = 'block';
			document.getElementById('tank-content').style.display = 'none';
			document.getElementById('amplifier-content').style.display = 'none';

		}

		function showTank() {
			document.getElementById('assault-content').style.display = 'none';
			document.getElementById('tank-content').style.display = 'block';
			document.getElementById('amplifier-content').style.display = 'none';
		}

		function showAmplifier() {
			document.getElementById('assault-content').style.display = 'none';
			document.getElementById('tank-content').style.display = 'none';
			document.getElementById('amplifier-content').style.display = 'block';
		}

		// Show character functions
		function showLucia() {
			document.getElementById('lucia-content').style.display = 'block';
			document.getElementById('bianca-content').style.display = 'none';
			document.getElementById('lee-content').style.display = 'none';
		}

		function showBianca() {
			document.getElementById('lucia-content').style.display = 'none';
			document.getElementById('bianca-content').style.display = 'block';
			document.getElementById('lee-content').style.display = 'none';
		}

		function showLee() {
			document.getElementById('lucia-content').style.display = 'none';
			document.getElementById('bianca-content').style.display = 'none';
			document.getElementById('lee-content').style.display = 'block';
		}
		
		function showNanami() {
			document.getElementById('nanami-content').style.display = 'block';
			document.getElementById('chrome-content').style.display = 'none';
			document.getElementById('karenina-content').style.display = 'none';
		}

		function showChrome() {
			document.getElementById('nanami-content').style.display = 'none';
			document.getElementById('chrome-content').style.display = 'block';
			document.getElementById('karenina-content').style.display = 'none';
		}

		function showKarenina() {
			document.getElementById('nanami-content').style.display = 'none';
			document.getElementById('chrome-content').style.display = 'none';
			document.getElementById('karenina-content').style.display = 'block';
		}
		
		// Show/hide form functions
		function showForm() {
			document.querySelector('.form-container').style.display = 'block';
		}

		function hideForm() {
			document.querySelector('.form-container').style.display = 'none';
		}

		function showXxi() {
			document.getElementById('xxi-content').style.display = 'block';
			document.getElementById('selena-content').style.display = 'none';
			document.getElementById('liv-content').style.display = 'none';
		}
		
		function showSelena() {
			document.getElementById('xxi-content').style.display = 'none';
			document.getElementById('selena-content').style.display = 'block';
			document.getElementById('liv-content').style.display = 'none';
		}
		
		function showLiv() {
			document.getElementById('xxi-content').style.display = 'none';
			document.getElementById('selena-content').style.display = 'none';
			document.getElementById('liv-content').style.display = 'block';
		}
		
		//audio function
		function playAudio() {
			var audio = document.getElementById("myAudio");
			var loader = document.querySelector(".loader");
  
			if (audio.paused) {
				audio.play();
				loader.classList.add("playing");
				loader.classList.remove("paused");
			} 
			else {
				audio.pause();
				loader.classList.remove("playing");
				loader.classList.add("paused");
			}
		}